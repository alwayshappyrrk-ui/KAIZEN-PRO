package com.kaizenpro.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import android.media.RingtoneManager
import java.util.Calendar

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val title = intent.getStringExtra("title") ?: "KAIZEN PRO Task"
        val index = intent.getIntExtra("taskIndex", -1)
        val interval = intent.getIntExtra("intervalDays", 7).coerceAtLeast(1)
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val mode = context.getSharedPreferences("kaizen_tasks", Context.MODE_PRIVATE).getString("alarm_mode", "normal") ?: "normal"
        val channelId = if (mode == "loud") "kaizen_reminders_loud_v2" else "kaizen_reminders_normal_v2"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val normal = NotificationChannel("kaizen_reminders_normal_v2", "KAIZEN Normal Reminders", NotificationManager.IMPORTANCE_HIGH)
            val loud = NotificationChannel("kaizen_reminders_loud_v2", "KAIZEN Loud Alarm", NotificationManager.IMPORTANCE_HIGH).apply {
                description = "Task reminders with alarm sound and vibration"
                setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM), android.media.AudioAttributes.Builder().setUsage(android.media.AudioAttributes.USAGE_ALARM).setContentType(android.media.AudioAttributes.CONTENT_TYPE_SONIFICATION).build())
                enableVibration(true)
                vibrationPattern = longArrayOf(0, 700, 300, 700, 300, 1000)
            }
            nm.createNotificationChannel(normal)
            nm.createNotificationChannel(loud)
        }
        val openApp = PendingIntent.getActivity(context, 9900, Intent(context, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0)
        val notification = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(context, channelId).setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle("KAIZEN PRO • Reminder").setContentText(title)
                .setContentIntent(openApp).setAutoCancel(true).setPriority(Notification.PRIORITY_HIGH)
                .setVibrate(if (mode == "loud") longArrayOf(0, 700, 300, 700, 300, 1000) else longArrayOf(0, 250)).build()
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(context).setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle("KAIZEN PRO • Reminder").setContentText(title)
                .setContentIntent(openApp).setAutoCancel(true).setPriority(Notification.PRIORITY_HIGH)
                .setVibrate(if (mode == "loud") longArrayOf(0, 700, 300, 700, 300, 1000) else longArrayOf(0, 250)).build()
        }
        nm.notify(8000 + index.coerceAtLeast(0), notification)

        // Move the recurring task's next due date forward and schedule its next reminder.
        if (index >= 0) {
            val prefs = context.getSharedPreferences("kaizen_tasks", Context.MODE_PRIVATE)
            val count = prefs.getInt("count", 0)
            if (index < count && (prefs.getString("type_$index", "Daily") == "Recurring")) {
                val nextDue = (System.currentTimeMillis() / 86400000L + interval) * 86400000L
                prefs.edit().putLong("due_$index", nextDue).apply()
                val nextIntent = Intent(context, ReminderReceiver::class.java).apply {
                    putExtra("title", title)
                    putExtra("taskIndex", index)
                    putExtra("intervalDays", interval)
                    putExtra("reminderTime", intent.getStringExtra("reminderTime") ?: "20:00")
                }
                val pending = PendingIntent.getBroadcast(context, 7000 + index, nextIntent,
                    PendingIntent.FLAG_UPDATE_CURRENT or if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0)
                val parts = (intent.getStringExtra("reminderTime") ?: "20:00").split(":")
                val cal = Calendar.getInstance().apply {
                    timeInMillis = nextDue
                    set(Calendar.HOUR_OF_DAY, parts.getOrNull(0)?.toIntOrNull() ?: 20)
                    set(Calendar.MINUTE, parts.getOrNull(1)?.toIntOrNull() ?: 0)
                    set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
                }
                val am = context.getSystemService(Context.ALARM_SERVICE) as android.app.AlarmManager
                if (Build.VERSION.SDK_INT >= 23) am.setAndAllowWhileIdle(android.app.AlarmManager.RTC_WAKEUP, cal.timeInMillis, pending)
                else am.set(android.app.AlarmManager.RTC_WAKEUP, cal.timeInMillis, pending)
            }
        }
    }
}
