# KAIZEN PRO V2 — Android source

This update expands the starter app with in-app navigation, Dashboard, Daily Tasks, Recurring Tasks, Upcoming Tasks, starter Fitness/Brain/Personality sections, a basic on-screen money calculator, 90-day challenge counter, and basic progress summary.

- Package: `com.kaizenpro.app`
- Existing SharedPreferences keys for daily tasks are preserved; recurrence fields are added with defaults.
- Offline-first task storage.

## Important limitations
- Notifications, exact alarms, voice reminders, weekly/monthly history, and backup/restore are **not implemented yet**. The recurring-task screen stores intervals and updates the next due date when a recurring task is checked complete, but does not send notifications.
- Money values are a temporary on-screen calculator and are not persisted.
- Test on a copy first. Do not uninstall the current app until you have backed up anything important. Since this project has no export/restore yet, existing local task data may not migrate to a different app install/signing identity.

Build with Java 17 and Android Gradle Plugin 8.6.1 / Gradle 8.7.
