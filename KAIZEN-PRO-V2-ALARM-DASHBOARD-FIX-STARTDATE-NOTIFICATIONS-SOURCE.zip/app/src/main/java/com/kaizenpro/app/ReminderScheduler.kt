package com.kaizenpro.app

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import java.util.Calendar

/** Shared reminder scheduling for app edits, delivery, and device restarts. */
object ReminderScheduler {
    fun scheduleAll(context: Context) {
        val prefs = context.getSharedPreferences("kaizen_tasks", Context.MODE_PRIVATE)
        val count = prefs.getInt("count", 0)
        val alarms = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        for (index in 0 until count) {
            val intent = Intent(context, ReminderReceiver::class.java).apply {
                putExtra("title", prefs.getString("title_$index", "KAIZEN PRO Task") ?: "KAIZEN PRO Task")
                putExtra("taskIndex", index)
                putExtra("intervalDays", prefs.getInt("interval_$index", 7).coerceAtLeast(1))
                putExtra("reminderTime", prefs.getString("time_$index", "20:00") ?: "20:00")
            }
            val pending = PendingIntent.getBroadcast(
                context, 7000 + index, intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            val recurring = prefs.getString("type_$index", "Daily") == "Recurring"
            val enabled = prefs.getBoolean("reminder_enabled_$index", true)
            var dueAt = prefs.getLong("due_$index", 0L)
            if (!recurring || !enabled) {
                alarms.cancel(pending)
                continue
            }

            val intervalDays = prefs.getInt("interval_$index", 7).coerceAtLeast(1)
            val reminderTime = prefs.getString("time_$index", "20:00") ?: "20:00"
            if (dueAt <= 0L) dueAt = Calendar.getInstance().apply {
                set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0)
                set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
            }.timeInMillis

            var triggerAt = triggerFor(dueAt, reminderTime)
            val now = System.currentTimeMillis()
            while (triggerAt.timeInMillis <= now) {
                val nextDue = Calendar.getInstance().apply {
                    timeInMillis = dueAt
                    set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0)
                    set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
                    add(Calendar.DAY_OF_YEAR, intervalDays)
                }
                dueAt = nextDue.timeInMillis
                triggerAt = triggerFor(dueAt, reminderTime)
            }
            prefs.edit().putLong("due_$index", dueAt).apply()
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && alarms.canScheduleExactAlarms()) {
                alarms.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt.timeInMillis, pending)
            } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                // Android may defer this fallback while idle. The app offers exact-alarm access in Settings.
                alarms.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt.timeInMillis, pending)
            } else {
                alarms.set(AlarmManager.RTC_WAKEUP, triggerAt.timeInMillis, pending)
            }
        }
    }

    /** First occurrence is on the selected start date, unless its reminder time has passed. */
    fun firstDueDate(startDate: Long, intervalDays: Int, reminderTime: String, now: Long = System.currentTimeMillis()): Long {
        val interval = intervalDays.coerceAtLeast(1)
        val due = Calendar.getInstance().apply {
            timeInMillis = startDate
            set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        }
        var trigger = triggerFor(due.timeInMillis, reminderTime)
        while (trigger.timeInMillis <= now) {
            due.add(Calendar.DAY_OF_YEAR, interval)
            trigger = triggerFor(due.timeInMillis, reminderTime)
        }
        return due.timeInMillis
    }

    private fun triggerFor(dueAt: Long, reminderTime: String): Calendar {
        val parts = reminderTime.split(":")
        return Calendar.getInstance().apply {
            timeInMillis = dueAt
            set(Calendar.HOUR_OF_DAY, parts.getOrNull(0)?.toIntOrNull()?.coerceIn(0, 23) ?: 20)
            set(Calendar.MINUTE, parts.getOrNull(1)?.toIntOrNull()?.coerceIn(0, 59) ?: 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
    }

    fun nextDueDate(previousDueAt: Long, intervalDays: Int): Long {
        val next = Calendar.getInstance().apply {
            timeInMillis = if (previousDueAt > 0L) previousDueAt else System.currentTimeMillis()
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
            add(Calendar.DAY_OF_YEAR, intervalDays.coerceAtLeast(1))
        }
        while (next.timeInMillis <= System.currentTimeMillis()) {
            next.add(Calendar.DAY_OF_YEAR, intervalDays.coerceAtLeast(1))
        }
        return next.timeInMillis
    }
}
