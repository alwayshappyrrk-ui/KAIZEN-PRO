package com.kaizenpro.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build

class ReminderReceiver : BroadcastReceiver() {
    companion object {
        const val CHANNEL_ID = "kaizen_reminders_v3"
    }

    override fun onReceive(context: Context, intent: Intent) {
        val title = intent.getStringExtra("title") ?: "KAIZEN PRO Task"
        val index = intent.getIntExtra("taskIndex", -1)
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            nm.createNotificationChannel(NotificationChannel(
                CHANNEL_ID, "KAIZEN PRO Alarms", NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Recurring task reminders"
                setSound(android.provider.Settings.System.DEFAULT_ALARM_ALERT_URI,
                    android.media.AudioAttributes.Builder()
                        .setUsage(android.media.AudioAttributes.USAGE_ALARM)
                        .setContentType(android.media.AudioAttributes.CONTENT_TYPE_SONIFICATION).build())
                enableVibration(true)
                vibrationPattern = longArrayOf(0, 500, 250, 500, 250, 700)
            })
        }
        val openApp = PendingIntent.getActivity(context, 9900,
            Intent(context, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(context, CHANNEL_ID)
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(context)
        }
        val notification = builder.setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("KAIZEN PRO • Reminder")
            .setContentText(title)
            .setCategory(Notification.CATEGORY_ALARM)
            .setContentIntent(openApp)
            .setAutoCancel(true)
            .setPriority(Notification.PRIORITY_HIGH)
            .setVibrate(longArrayOf(0, 500, 250, 500, 250, 700))
            .build()
        nm.notify(8000 + index.coerceAtLeast(0), notification)

        if (index >= 0) {
            val prefs = context.getSharedPreferences("kaizen_tasks", Context.MODE_PRIVATE)
            if (index < prefs.getInt("count", 0) &&
                prefs.getString("type_$index", "Daily") == "Recurring" &&
                prefs.getBoolean("reminder_enabled_$index", true)) {
                val nextDue = ReminderScheduler.nextDueDate(
                    prefs.getLong("due_$index", 0L), prefs.getInt("interval_$index", 7)
                )
                prefs.edit().putLong("due_$index", nextDue).apply()
                ReminderScheduler.scheduleAll(context)
            }
        }
    }
}
