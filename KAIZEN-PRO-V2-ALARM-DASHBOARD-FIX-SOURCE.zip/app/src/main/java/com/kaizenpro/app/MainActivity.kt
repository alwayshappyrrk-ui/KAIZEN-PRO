package com.kaizenpro.app

import android.app.Activity
import android.app.AlarmManager
import android.app.PendingIntent
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.app.AlertDialog
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private val bg = Color.rgb(12, 12, 14)
    private val card = Color.rgb(27, 27, 31)
    private val red = Color.rgb(235, 42, 55)
    private val white = Color.WHITE
    private val muted = Color.rgb(180, 180, 190)
    private val prefs by lazy { getSharedPreferences("kaizen_tasks", MODE_PRIVATE) }
    private val tasks = mutableListOf<Task>()
    private lateinit var root: LinearLayout
    private lateinit var content: LinearLayout
    private var page = "Dashboard"

    data class Task(
        var title: String,
        var priority: String,
        var done: Boolean,
        var type: String = "Daily",
        var intervalDays: Int = 0,
        var dueAt: Long = 0L,
        var reminderTime: String = "20:00"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        createNotificationChannel()
        loadTasks()
        scheduleAllReminders()
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 501)
        }
        render()
    }

    private fun loadTasks() {
        val count = prefs.getInt("count", -1)
        if (count < 0) {
            tasks.add(Task("उठल्यावर पाणी पिणे", "P2", false))
            tasks.add(Task("आजची 3 महत्त्वाची कामे ठरवणे", "P1", false))
            tasks.add(Task("15 मिनिटे चालणे / व्यायाम", "P2", false))
            tasks.add(Task("व्यवसायाची विक्री नोंदवणे", "P1", false))
            saveTasks()
        } else {
            for (i in 0 until count) {
                val title = prefs.getString("title_$i", "") ?: ""
                if (title.isBlank()) continue
                tasks.add(Task(title,
                    prefs.getString("priority_$i", "P3") ?: "P3",
                    prefs.getBoolean("done_$i", false),
                    prefs.getString("type_$i", "Daily") ?: "Daily",
                    prefs.getInt("interval_$i", 0),
                    prefs.getLong("due_$i", 0L),
                    prefs.getString("time_$i", "20:00") ?: "20:00"))
            }
        }
    }

    private fun saveTasks() {
        prefs.edit().apply {
            putInt("count", tasks.size)
            tasks.forEachIndexed { i, t ->
                putString("title_$i", t.title); putString("priority_$i", t.priority)
                putBoolean("done_$i", t.done); putString("type_$i", t.type)
                putInt("interval_$i", t.intervalDays); putLong("due_$i", t.dueAt)
                putString("time_$i", t.reminderTime)
            }
            apply()
        }
        scheduleAllReminders()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel("kaizen_reminders_v2", "KAIZEN Loud Reminders", NotificationManager.IMPORTANCE_HIGH).apply { setSound(android.provider.Settings.System.DEFAULT_ALARM_ALERT_URI, android.media.AudioAttributes.Builder().setUsage(android.media.AudioAttributes.USAGE_ALARM).setContentType(android.media.AudioAttributes.CONTENT_TYPE_SONIFICATION).build()); enableVibration(true); vibrationPattern = longArrayOf(0, 500, 250, 500, 250, 700) }
            channel.description = "Recurring task reminders"
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun scheduleAllReminders() {
        val alarmManager = getSystemService(ALARM_SERVICE) as AlarmManager
        tasks.forEachIndexed { index, task ->
            val requestCode = 7000 + index
            val intent = Intent(this, ReminderReceiver::class.java).apply {
                putExtra("title", task.title)
                putExtra("taskIndex", index)
                putExtra("intervalDays", task.intervalDays.coerceAtLeast(1))
                putExtra("reminderTime", task.reminderTime)
            }
            val pending = PendingIntent.getBroadcast(this, requestCode, intent,
                PendingIntent.FLAG_UPDATE_CURRENT or if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0)
            if (task.type == "Recurring" && task.dueAt > System.currentTimeMillis()) {
                val parts = task.reminderTime.split(":")
                val cal = Calendar.getInstance().apply {
                    timeInMillis = task.dueAt
                    set(Calendar.HOUR_OF_DAY, parts.getOrNull(0)?.toIntOrNull() ?: 20)
                    set(Calendar.MINUTE, parts.getOrNull(1)?.toIntOrNull() ?: 0)
                    set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
                }
                if (cal.timeInMillis <= System.currentTimeMillis()) cal.add(Calendar.DAY_OF_YEAR, 1)
                if (Build.VERSION.SDK_INT >= 23) alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pending)
                else alarmManager.set(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pending)
            } else {
                alarmManager.cancel(pending)
            }
        }
    }

    private fun render() {
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(bg); setPadding(dp(16), dp(16), dp(16), dp(18)) }
        val scroll = ScrollView(this); scroll.addView(root); setContentView(scroll)
        text(root, "KAIZEN PRO", 28f, red, true)
        text(root, "NO EXCUSES. JUST ACTION.", 12f, muted, true, 0, 12)
        val nav = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(nav, matchWrap())
        listOf("Dashboard", "Daily Tasks", "Recurring Tasks", "Upcoming Tasks", "Fitness", "Brain Development", "Personality Development", "Money Management", "90 Days Challenge", "Progress Reports", "Settings / Backup").chunked(2).forEach { pair ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            pair.forEach { label ->
                val b = Button(this).apply {
                    text = label; textSize = 11f; setTextColor(white)
                    setBackgroundColor(if (page == label) red else card)
                    setOnClickListener { page = label; render() }
                }
                val lp = LinearLayout.LayoutParams(0, dp(48), 1f); lp.setMargins(dp(3), dp(3), dp(3), dp(3)); row.addView(b, lp)
            }
            if (pair.size == 1) row.addView(Space(this), LinearLayout.LayoutParams(0, dp(48), 1f))
            nav.addView(row)
        }
        text(root, when(page) {
            "Dashboard" -> "तुझा वैयक्तिक प्रगती आढावा"
            "Daily Tasks" -> "आजची कामं"
            "Recurring Tasks" -> "🔁 पुन्हा पुन्हा करायची कामं"
            "Upcoming Tasks" -> "📅 पुढील ७ दिवस"
            else -> page
        }, 21f, white, true, 12, 8)
        content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(content, matchWrap())
        when(page) {
            "Dashboard" -> showDashboard()
            "Daily Tasks" -> showTasks("Daily")
            "Recurring Tasks" -> showTasks("Recurring")
            "Upcoming Tasks" -> showUpcoming()
            "Fitness" -> showCategory("Fitness", listOf("15 मिनिटे चालणे / व्यायाम", "पाणी पिण्याची नोंद", "झोपेची वेळ नोंदवणे"))
            "Brain Development" -> showCategory("Brain", listOf("10 मिनिटे वाचन", "आज शिकलेली एक गोष्ट लिहा", "स्मरणशक्तीचा सराव"))
            "Personality Development" -> showCategory("Personality", listOf("10 मिनिटे बोलण्याचा सराव", "आजची एक सुधारणा लिहा", "नवीन कौशल्याचा सराव"))
            "Money Management" -> showMoney()
            "90 Days Challenge" -> showChallenge()
            "Progress Reports" -> showReports()
            "Settings / Backup" -> showSettings()
            else -> showDashboard()
        }
        text(root, "कामे Offline सेव्ह होतात. Recurring Reminder साठी सूचना परवानगी आवश्यक आहे.", 12f, muted, false, 12, 0)
    }

    private fun showDashboard() {
        val daily = tasks.filter { it.type == "Daily" }
        val done = daily.count { it.done }; val pct = if (daily.isEmpty()) 0 else done * 100 / daily.size
        panel("TODAY'S MISSION", "$pct% • $done / ${daily.size} कामं पूर्ण")
        val recurring = tasks.count { it.type == "Recurring" }
        panel("RECURRING TASKS", "$recurring कामे नियोजित")
        panel("UPCOMING", "पुढील ७ दिवसांतील ${tasks.count { it.dueAt > 0L }} नियोजित कामे")
        button(content, "+ रोजचे काम जोडा", red) { addTaskDialog("Daily") }
        button(content, "+ Recurring काम जोडा", red) { addTaskDialog("Recurring") }
        button(content, "आजची कामं Reset करा", card) {
            AlertDialog.Builder(this).setTitle("Reset करायचं?").setMessage("फक्त रोजच्या कामांच्या पूर्ण खूणा काढल्या जातील.")
                .setNegativeButton("रद्द", null).setPositiveButton("Reset") { _, _ -> daily.forEach { it.done = false }; saveTasks(); render() }.show()
        }
    }

    private fun showTasks(type: String) {
        val filtered = tasks.withIndex().filter { it.value.type == type }
        if (filtered.isEmpty()) text(content, "या विभागात अजून कामे नाहीत.", 15f, muted, false, 0, 8)
        filtered.forEach { indexed ->
            val i = indexed.index; val t = indexed.value
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(8), dp(6), dp(4), dp(6)); setBackgroundColor(card) }
            val cb = CheckBox(this).apply { isChecked = t.done; buttonTintList = android.content.res.ColorStateList.valueOf(if (t.done) Color.GREEN else red) }
            cb.setOnCheckedChangeListener { _, checked ->
                if (t.type == "Recurring" && checked) {
                    t.done = true
                    t.dueAt = (System.currentTimeMillis() / 86400000L + t.intervalDays) * 86400000L
                    Toast.makeText(this, "पूर्ण! पुढील तारीख ${formatDate(t.dueAt)}", Toast.LENGTH_LONG).show()
                } else t.done = checked
                saveTasks(); render()
            }
            row.addView(cb)
            val detail = if (t.type == "Recurring") "\n${t.intervalDays} दिवसांनी • पुढील तारीख: ${if (t.dueAt > 0L) formatDate(t.dueAt) else "अजून ठरलेली नाही"} • ${t.reminderTime}" else "\n${t.priority}"
            val label = TextView(this).apply { text = t.title + detail; textSize = 14f; setTextColor(if (t.done) muted else white); setPadding(dp(4), 0, dp(4), 0); layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f) }
            row.addView(label)
            val del = Button(this).apply { text = "×"; setTextColor(red); setBackgroundColor(card); setOnClickListener { AlertDialog.Builder(this@MainActivity).setTitle("काम डिलीट करायचं?").setMessage(t.title).setNegativeButton("रद्द", null).setPositiveButton("डिलीट") { _, _ -> tasks.removeAt(i); saveTasks(); render() }.show() } }
            row.addView(del)
            val lp = matchWrap(); lp.bottomMargin = dp(7); content.addView(row, lp)
        }
        button(content, if (type == "Recurring") "+ नवीन Recurring काम" else "+ नवीन काम जोडा", red) { addTaskDialog(type) }
    }

    private fun showUpcoming() {
        val now = System.currentTimeMillis(); val end = now + 7L * 86400000L
        val upcoming = tasks.filter { it.dueAt in now..end }
        if (upcoming.isEmpty()) text(content, "पुढील ७ दिवसांसाठी नियोजित कामे नाहीत.", 15f, muted, false)
        upcoming.sortedBy { it.dueAt }.forEach { panel(it.title, "${formatDate(it.dueAt)} • ${it.type}") }
    }

    private fun showCategory(type: String, examples: List<String>) {
        text(content, "ही सुरुवातीची नमुना कामे आहेत. + बटणाने तुमची कामे जोडा.", 13f, muted, false, 0, 8)
        examples.forEach { name -> button(content, "+ $name", card) { tasks.add(Task(name, "P2", false, "Daily")); saveTasks(); Toast.makeText(this, "काम Daily Tasks मध्ये जोडले", Toast.LENGTH_SHORT).show(); page = "Daily Tasks"; render() } }
        button(content, "या विभागासाठी काम जोडा", red) { addTaskDialog("Daily") }
    }

    private fun showMoney() {
        text(content, "साधा उत्पन्न/खर्च हिशेब", 15f, muted, false, 0, 8)
        val income = EditText(this).apply { hint = "उत्पन्न (₹)"; inputType = 2; setTextColor(white); setHintTextColor(muted) }
        val expense = EditText(this).apply { hint = "खर्च (₹)"; inputType = 2; setTextColor(white); setHintTextColor(muted) }
        content.addView(income, matchWrap()); content.addView(expense, matchWrap())
        val result = text(content, "निव्वळ: ₹0", 20f, white, true, 8, 8)
        button(content, "हिशेब काढा", red) { val a = income.text.toString().toDoubleOrNull() ?: 0.0; val b = expense.text.toString().toDoubleOrNull() ?: 0.0; result.text = "निव्वळ: ₹${a-b}" }
        text(content, "टीप: हा हिशेब सध्या स्क्रीनवरच आहे; कायमस्वरूपी नोंद/रिपोर्ट पुढील टप्प्यात जोडायचा आहे.", 12f, muted, false, 8, 0)
    }

    private fun showChallenge() {
        val start = prefs.getLong("challenge_start", 0L)
        if (start == 0L) {
            text(content, "९० दिवसांचा वैयक्तिक सुधारणा प्रवास सुरू करा.", 15f, muted, false, 0, 8)
            button(content, "90 Days Challenge सुरू करा", red) { prefs.edit().putLong("challenge_start", System.currentTimeMillis()).apply(); render() }
        } else {
            val day = ((System.currentTimeMillis() - start) / 86400000L + 1).toInt().coerceIn(1, 90)
            panel("90 DAYS CHALLENGE", "दिवस $day / 90")
            val bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 90; progress = day; progressTintList = android.content.res.ColorStateList.valueOf(red) }
            content.addView(bar, matchWrap())
            button(content, "Challenge पुन्हा सुरू करा", card) { AlertDialog.Builder(this).setMessage("नवीन ९० दिवसांचा प्रवास सुरू करायचा?").setNegativeButton("रद्द", null).setPositiveButton("हो") { _, _ -> prefs.edit().putLong("challenge_start", System.currentTimeMillis()).apply(); render() }.show() }
        }
    }

    private fun showReports() {
        val daily = tasks.filter { it.type == "Daily" }; val recurring = tasks.filter { it.type == "Recurring" }
        panel("सर्व कामे", "${tasks.size}")
        panel("रोजची कामे पूर्ण", "${daily.count { it.done }} / ${daily.size}")
        panel("Recurring कामे", "${recurring.size} • पूर्ण केलेली ${recurring.count { it.done }}")
        text(content, "हा प्राथमिक आढावा आहे. साप्ताहिक/मासिक इतिहास पुढील टप्प्यात जोडायचा आहे.", 12f, muted, false, 8, 0)
    }

    private fun showSettings() {
        panel("डेटा", "कामे या फोनच्या SharedPreferences मध्ये सेव्ह होतात.")
        button(content, "डेटा Export / Backup", card) { Toast.makeText(this, "Export/Restore सुविधा अद्याप जोडलेली नाही.", Toast.LENGTH_LONG).show() }
        text(content, "जुने ॲप अनइन्स्टॉल करू नका. या आवृत्तीची चाचणी करताना डेटा बॅकअप आवश्यक आहे.", 13f, muted, false, 8, 0)
    }

    private fun addTaskDialog(type: String) {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(8), dp(20), 0) }
        val input = EditText(this).apply { hint = "कामाचं नाव"; setTextColor(white); setHintTextColor(muted) }; box.addView(input)
        val priority = Spinner(this).apply { adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, listOf("P1 - तातडीचे", "P2 - महत्त्वाचे", "P3 - सामान्य", "P4 - कमी")) }; box.addView(priority)
        var interval = 7
        var reminder = "20:00"
        var dueDate = 0L
        if (type == "Recurring") {
            text(box, "पुनरावृत्ती किती दिवसांनी?", 14f, white, true, 8, 2)
            val choices = listOf("दर 2 दिवसांनी", "दर 3 दिवसांनी", "दर 4 दिवसांनी", "दर 7 दिवसांनी", "दर 15 दिवसांनी", "दर 30 दिवसांनी", "स्वतःचे दिवस")
            val intervals = listOf(2,3,4,7,15,30,0)
            val repeat = Spinner(this).apply { adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, choices) }; box.addView(repeat)
            val custom = EditText(this).apply { hint = "स्वतःचे दिवस (पर्यायी)"; inputType = 2; setTextColor(white); setHintTextColor(muted) }; box.addView(custom)
            val timeButton = Button(this).apply { text = "रिमाइंडर वेळ: 20:00"; setOnClickListener { TimePickerDialog(this@MainActivity, { _, h, m -> reminder = String.format(Locale.US, "%02d:%02d", h, m); text = "रिमाइंडर वेळ: $reminder" }, 20, 0, true).show() } }; box.addView(timeButton)
            repeat.setOnItemSelectedListener(object : AdapterView.OnItemSelectedListener {
                override fun onNothingSelected(parent: AdapterView<*>?) {}
                override fun onItemSelected(parent: AdapterView<*>?, view: android.view.View?, position: Int, id: Long) { interval = intervals[position]; custom.isEnabled = interval == 0 }
            })
            AlertDialog.Builder(this).setTitle("नवीन Recurring काम").setView(box).setNegativeButton("रद्द", null).setPositiveButton("सेव्ह") { _, _ ->
                val name = input.text.toString().trim()
                val days = if (interval == 0) custom.text.toString().toIntOrNull() ?: 7 else interval
                if (name.isNotBlank()) { val p = listOf("P1","P2","P3","P4")[priority.selectedItemPosition]; val next = (System.currentTimeMillis() / 86400000L + days) * 86400000L; tasks.add(Task(name,p,false,"Recurring",days.coerceAtLeast(1),next,reminder)); saveTasks(); render() } else Toast.makeText(this, "कामाचं नाव लिहा", Toast.LENGTH_SHORT).show()
            }.show()
        } else {
            AlertDialog.Builder(this).setTitle("नवीन काम").setView(box).setNegativeButton("रद्द", null).setPositiveButton("जोडा") { _, _ ->
                val name = input.text.toString().trim(); if (name.isNotBlank()) { tasks.add(Task(name, listOf("P1","P2","P3","P4")[priority.selectedItemPosition], false, type)); saveTasks(); render() } else Toast.makeText(this,"कामाचं नाव लिहा",Toast.LENGTH_SHORT).show()
            }.show()
        }
    }

    private fun panel(title: String, detail: String) {
        val p = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(12), dp(14), dp(12)); setBackgroundColor(card) }
        text(p, title, 13f, red, true); text(p, detail, 19f, white, true, 4, 0)
        val lp = matchWrap(); lp.bottomMargin = dp(8); content.addView(p, lp)
    }
    private fun formatDate(time: Long): String = SimpleDateFormat("dd MMM yyyy", Locale("mr", "IN")).format(Date(time))
    private fun text(parent: LinearLayout, value: String, size: Float, color: Int, bold: Boolean, top: Int = 0, bottom: Int = 0): TextView {
        val v = TextView(this).apply { text = value; textSize = size; setTextColor(color); if (bold) setTypeface(typeface, Typeface.BOLD); setPadding(0, dp(top), 0, dp(bottom)) }
        parent.addView(v, matchWrap()); return v
    }
    private fun button(parent: LinearLayout, label: String, color: Int, action: () -> Unit) {
        val b = Button(this).apply { text = label; textSize = 14f; setTextColor(white); setBackgroundColor(color); setOnClickListener { action() } }
        val lp = matchWrap(); lp.topMargin = dp(7); parent.addView(b, lp)
    }
    private fun matchWrap() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
}
