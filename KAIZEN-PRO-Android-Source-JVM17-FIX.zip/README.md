# KAIZEN PRO — Discipline & Growth

First Android source version, using a black/red theme.

## Included in this starter build
- Dark dashboard with progress percentage
- Add tasks and choose P1–P4 priority
- Mark tasks complete
- Delete a task with confirmation
- Reset today's completion marks without deleting tasks
- Local persistence with Android SharedPreferences
- GitHub Actions workflow to build a debug APK

## Build
Push these files to the `main` branch of your GitHub repository. Open **Actions** and run **Build KAIZEN PRO APK**, or let the workflow start on push. Download the `KAIZEN-PRO-APK` artifact after a successful run.

Package: `com.kaizenpro.app`

## Important
This is a starter version. Task alarms, recurrence schedules, voice reminders, weekly reports, backup/export, and Drive sync are not included yet. The APK must be built and tested on a real device before relying on it.
