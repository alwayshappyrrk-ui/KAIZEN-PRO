package com.kaizenpro.app

import android.app.Activity
import android.app.AlertDialog
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {
    private val bg = Color.rgb(12, 12, 14)
    private val card = Color.rgb(27, 27, 31)
    private val red = Color.rgb(235, 42, 55)
    private val white = Color.WHITE
    private val muted = Color.rgb(180, 180, 190)
    private val prefs by lazy { getSharedPreferences("kaizen_tasks", MODE_PRIVATE) }
    private val taskRows = mutableListOf<Task>()
    private lateinit var root: LinearLayout
    private lateinit var list: LinearLayout
    private lateinit var progressText: TextView
    private lateinit var progressBar: ProgressBar

    data class Task(val title: String, val priority: String, var done: Boolean)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        loadTasks()
        render()
    }

    private fun loadTasks() {
        val count = prefs.getInt("count", -1)
        if (count < 0) {
            taskRows.add(Task("उठल्यावर पाणी पिणे", "P2", false))
            taskRows.add(Task("आजची 3 महत्त्वाची कामे ठरवणे", "P1", false))
            taskRows.add(Task("15 मिनिटे चालणे / व्यायाम", "P2", false))
            taskRows.add(Task("व्यवसायाची विक्री नोंदवणे", "P1", false))
            saveTasks()
        } else {
            for (i in 0 until count) {
                val title = prefs.getString("title_$i", "") ?: ""
                val priority = prefs.getString("priority_$i", "P3") ?: "P3"
                val done = prefs.getBoolean("done_$i", false)
                if (title.isNotBlank()) taskRows.add(Task(title, priority, done))
            }
        }
    }

    private fun saveTasks() {
        prefs.edit().apply {
            putInt("count", taskRows.size)
            taskRows.forEachIndexed { i, task ->
                putString("title_$i", task.title)
                putString("priority_$i", task.priority)
                putBoolean("done_$i", task.done)
            }
            apply()
        }
    }

    private fun render() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
            setPadding(dp(18), dp(20), dp(18), dp(16))
        }
        val scroll = ScrollView(this)
        scroll.addView(root)
        setContentView(scroll)

        text(root, "KAIZEN PRO", 28f, red, true)
        text(root, "NO EXCUSES. JUST ACTION.", 13f, muted, true)
        text(root, "आजचा दिवस तुझा आहे. कृती सुरू कर!", 17f, white, true, 0, 16)

        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(16))
            setBackgroundColor(card)
        }
        root.addView(panel, matchWrap())
        text(panel, "TODAY'S MISSION", 13f, red, true)
        progressText = text(panel, "", 24f, white, true, 0, 8)
        progressBar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            progressTintList = android.content.res.ColorStateList.valueOf(red)
        }
        panel.addView(progressBar, matchWrap())
        text(panel, "P1 = आधी करा  •  P2 = महत्त्वाचे  •  P3 = सामान्य", 12f, muted, false, 0, 4)

        text(root, "आजची कामं", 21f, white, true, 0, 8)
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(list, matchWrap())

        button(root, "+ नवीन काम जोडा", red) { addTaskDialog() }
        button(root, "आजची कामं Reset करा", card) {
            AlertDialog.Builder(this)
                .setTitle("कामं Reset करायची?")
                .setMessage("फक्त पूर्ण केलेल्या खूणा काढल्या जातील. कामांची यादी कायम राहील.")
                .setNegativeButton("रद्द", null)
                .setPositiveButton("Reset") { _, _ ->
                    taskRows.forEach { it.done = false }
                    saveTasks()
                    render()
                }.show()
        }
        text(root, "तुझी कामं या फोनमध्ये सेव्ह होतात. पहिली आवृत्ती — Offline.", 12f, muted, false, 0, 8)
        renderTasks()
        updateProgress()
    }

    private fun renderTasks() {
        list.removeAllViews()
        if (taskRows.isEmpty()) text(list, "अजून कामं नाहीत. नवीन काम जोडा.", 15f, muted, false, 0, 8)
        taskRows.forEachIndexed { index, task ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(10), dp(8), dp(8), dp(8))
                setBackgroundColor(card)
            }
            val check = CheckBox(this).apply {
                isChecked = task.done
                buttonTintList = android.content.res.ColorStateList.valueOf(if (task.done) Color.GREEN else red)
                setOnCheckedChangeListener { _, checked ->
                    task.done = checked
                    saveTasks()
                    updateProgress()
                    renderTasks()
                }
            }
            row.addView(check)
            val title = TextView(this).apply {
                text = task.title + "\n" + task.priority
                textSize = 15f
                setTextColor(if (task.done) muted else white)
                if (task.done) paintFlags = paintFlags or 0x10
                setPadding(dp(4), 0, dp(4), 0)
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            }
            row.addView(title)
            val delete = Button(this).apply {
                text = "×"
                textSize = 20f
                setTextColor(red)
                setBackgroundColor(card)
                setOnClickListener {
                    AlertDialog.Builder(this@MainActivity)
                        .setTitle("काम डिलीट करायचं?")
                        .setMessage(task.title)
                        .setNegativeButton("रद्द", null)
                        .setPositiveButton("डिलीट") { _, _ ->
                            taskRows.removeAt(index)
                            saveTasks()
                            render()
                        }.show()
                }
            }
            row.addView(delete)
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.bottomMargin = dp(8)
            list.addView(row, lp)
        }
    }

    private fun updateProgress() {
        if (!::progressText.isInitialized) return
        val done = taskRows.count { it.done }
        val total = taskRows.size
        val pct = if (total == 0) 0 else done * 100 / total
        progressText.text = "$pct%  •  $done / $total कामं पूर्ण"
        progressBar.progress = pct
    }

    private fun addTaskDialog() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(8), dp(20), 0)
        }
        val input = EditText(this).apply {
            hint = "कामाचं नाव लिहा"
            setTextColor(white)
            setHintTextColor(muted)
        }
        box.addView(input)
        val priority = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, listOf("P1 - तातडीचे", "P2 - महत्त्वाचे", "P3 - सामान्य", "P4 - कमी"))
        }
        box.addView(priority)
        AlertDialog.Builder(this)
            .setTitle("नवीन काम")
            .setView(box)
            .setNegativeButton("रद्द", null)
            .setPositiveButton("जोडा") { _, _ ->
                val name = input.text.toString().trim()
                if (name.isNotEmpty()) {
                    val p = listOf("P1", "P2", "P3", "P4")[priority.selectedItemPosition]
                    taskRows.add(Task(name, p, false))
                    saveTasks()
                    render()
                } else {
                    Toast.makeText(this, "कामाचं नाव लिहा", Toast.LENGTH_SHORT).show()
                }
            }.show()
    }

    private fun text(parent: LinearLayout, value: String, size: Float, color: Int, bold: Boolean, top: Int = 0, bottom: Int = 0): TextView {
        val view = TextView(this).apply {
            text = value
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
            setPadding(0, dp(top), 0, dp(bottom))
        }
        parent.addView(view, matchWrap())
        return view
    }

    private fun button(parent: LinearLayout, label: String, color: Int, action: () -> Unit) {
        val b = Button(this).apply {
            text = label
            textSize = 15f
            setTextColor(white)
            setBackgroundColor(color)
            setOnClickListener { action() }
        }
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.topMargin = dp(8)
        parent.addView(b, lp)
    }

    private fun matchWrap() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
}
