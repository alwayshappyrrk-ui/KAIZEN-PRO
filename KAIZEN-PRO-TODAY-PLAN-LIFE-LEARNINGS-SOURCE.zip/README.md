# KAIZEN PRO V2 — Android source

This update expands the starter app with in-app navigation, Dashboard, Daily Tasks, Recurring Tasks, Upcoming Tasks, starter Fitness/Brain/Personality sections, a basic on-screen money calculator, 90-day challenge counter, and basic progress summary.

- Package: `com.kaizenpro.app`
- Existing SharedPreferences keys for daily tasks are preserved; recurrence fields are added with defaults.
- Offline-first task storage.

## Reminder behavior
- Recurring tasks have an explicit alarm on/off switch and a selectable local reminder time.
- The app schedules exact alarms while Android's Alarms & reminders access is enabled. On Android 12 and later, enable it from Settings / Backup for more punctual delivery. If access is denied, Android's idle-friendly fallback can be delayed by the system.
- Pending reminders are restored after reboot, app update, time/date change, and timezone change.
- Android notification permission and the KAIZEN PRO notification channel must also be enabled for notifications to appear or make sound.
- Weekly/monthly history and backup/restore are not implemented yet. Money values are a temporary on-screen calculator and are not persisted.
- Money values are a temporary on-screen calculator and are not persisted.
- Test on a copy first. Do not uninstall the current app until you have backed up anything important. Since this project has no export/restore yet, existing local task data may not migrate to a different app install/signing identity.

Build with Java 17 and Android Gradle Plugin 8.6.1 / Gradle 8.7. The signed release workflow extracts this source ZIP and signs the APK with the repository's persistent Actions secrets.
