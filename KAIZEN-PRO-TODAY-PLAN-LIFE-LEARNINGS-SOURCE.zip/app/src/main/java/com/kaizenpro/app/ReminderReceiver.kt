package com.kaizenpro.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build

class ReminderReceiver : BroadcastReceiver() {
    companion object {
        private const val CHANNEL_PREFIX = "kaizen_reminders_v4_"

        fun channelId(context: Context): String {
            val uri = context.getSharedPreferences("kaizen_tasks", Context.MODE_PRIVATE)
                .getString("alarm_sound_uri", "")?.takeIf { it.isNotBlank() }
                ?: android.provider.Settings.System.DEFAULT_ALARM_ALERT_URI.toString()
            val encoded = android.util.Base64.encodeToString(
                uri.toByteArray(Charsets.UTF_8),
                android.util.Base64.URL_SAFE or android.util.Base64.NO_WRAP or android.util.Base64.NO_PADDING
            )
            return CHANNEL_PREFIX + encoded
        }

        fun ensureChannel(context: Context) {
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
            val prefs = context.getSharedPreferences("kaizen_tasks", Context.MODE_PRIVATE)
            val selected = prefs.getString("alarm_sound_uri", "")?.takeIf { it.isNotBlank() }?.let { Uri.parse(it) }
                ?: android.provider.Settings.System.DEFAULT_ALARM_ALERT_URI
            val audio = android.media.AudioAttributes.Builder()
                .setUsage(android.media.AudioAttributes.USAGE_ALARM)
                .setContentType(android.media.AudioAttributes.CONTENT_TYPE_SONIFICATION).build()
            val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val id = channelId(context)
            if (manager.getNotificationChannel(id) == null) {
                manager.createNotificationChannel(NotificationChannel(
                    id, "KAIZEN PRO Alarms", NotificationManager.IMPORTANCE_HIGH
                ).apply {
                    description = "Recurring task reminders"
                    setSound(selected, audio)
                    enableVibration(true)
                    vibrationPattern = longArrayOf(0, 500, 250, 500, 250, 700)
                })
            }
        }
    }

    override fun onReceive(context: Context, intent: Intent) {
        val title = intent.getStringExtra("title") ?: "KAIZEN PRO Task"
        val index = intent.getIntExtra("taskIndex", -1)
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        ensureChannel(context)
        val openApp = PendingIntent.getActivity(context, 9900,
            Intent(context, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(context, channelId(context))
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(context)
        }
        val notification = builder.setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("KAIZEN PRO • Reminder")
            .setContentText(title)
            .setCategory(Notification.CATEGORY_ALARM)
            .setContentIntent(openApp)
            .setAutoCancel(true)
            .setPriority(Notification.PRIORITY_HIGH)
            .setVibrate(longArrayOf(0, 500, 250, 500, 250, 700))
            .build()
        nm.notify(8000 + index.coerceAtLeast(0), notification)

        if (index >= 0) {
            val prefs = context.getSharedPreferences("kaizen_tasks", Context.MODE_PRIVATE)
            if (index < prefs.getInt("count", 0) &&
                prefs.getString("type_$index", "Daily") == "Recurring" &&
                prefs.getBoolean("reminder_enabled_$index", true)) {
                val nextDue = ReminderScheduler.nextDueDate(
                    prefs.getLong("due_$index", 0L), prefs.getInt("interval_$index", 7)
                )
                prefs.edit().putLong("due_$index", nextDue).apply()
                ReminderScheduler.scheduleAll(context)
            }
        }
    }
}
