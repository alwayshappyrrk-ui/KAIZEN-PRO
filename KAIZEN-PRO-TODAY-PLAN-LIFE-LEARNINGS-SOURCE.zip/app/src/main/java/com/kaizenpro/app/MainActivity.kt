package com.kaizenpro.app

import android.app.Activity
import android.app.AlarmManager
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.app.AlertDialog
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.ActivityNotFoundException
import android.graphics.Color
import android.graphics.Typeface
import android.media.RingtoneManager
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import android.net.Uri
import org.json.JSONObject

class MainActivity : Activity() {
    private val bg = Color.rgb(12, 12, 14)
    private val card = Color.rgb(27, 27, 31)
    private val red = Color.rgb(235, 42, 55)
    private val freeSlotCard = Color.rgb(20, 48, 52)
    private val freeSlotAccent = Color.rgb(91, 220, 198)
    private val white = Color.WHITE
    private val muted = Color.rgb(180, 180, 190)
    private val prefs by lazy { getSharedPreferences("kaizen_tasks", MODE_PRIVATE) }
    private val tasks = mutableListOf<Task>()
    private lateinit var root: LinearLayout
    private lateinit var content: LinearLayout
    private var page = "Dashboard"
    private var ringtoneButtonToUpdate: Button? = null

    data class Task(
        var title: String,
        var priority: String,
        var done: Boolean,
        var type: String = "Daily",
        var intervalDays: Int = 0,
        var dueAt: Long = 0L,
        var reminderTime: String = "20:00",
        var reminderEnabled: Boolean = true,
        var slotTime: String = "",
        var durationMinutes: Int = 60,
        var doneDate: String = ""
    )

    data class Learning(var date: String, var note: String)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        createNotificationChannel()
        loadTasks()
        scheduleAllReminders()
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 501)
        }
        render()
    }

    override fun onResume() {
        super.onResume()
        ReminderScheduler.scheduleAll(this)
        var resetDaily = false
        tasks.forEach { task ->
            if (task.type == "Daily" && task.done && task.doneDate != todayKey()) {
                task.done = false
                task.doneDate = ""
                resetDaily = true
            }
        }
        if (resetDaily) {
            saveTasks()
            if (page == "Dashboard" || page == "Daily Tasks" || page == "Today Plan") render()
        }
        if (page == "Settings / Backup") render()
    }

    @Deprecated("Deprecated by Android; still used for the system ringtone picker on supported versions.")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 503) {
            if (resultCode == RESULT_OK && data?.data != null) exportBackup(data.data!!)
            return
        }
        if (requestCode == 504) {
            if (resultCode == RESULT_OK && data?.data != null) confirmBackupRestore(data.data!!)
            return
        }
        if (requestCode != 502) return
        val targetButton = ringtoneButtonToUpdate
        ringtoneButtonToUpdate = null
        if (resultCode != RESULT_OK) return
        val picked = data?.getParcelableExtra<Uri>(RingtoneManager.EXTRA_RINGTONE_PICKED_URI)
            ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
            ?: android.provider.Settings.System.DEFAULT_ALARM_ALERT_URI
        prefs.edit().putString("alarm_sound_uri", picked.toString()).apply()
        createNotificationChannel()
        targetButton?.text = "🔔 Alarm आवाज: ${alarmSoundName(picked)}"
        Toast.makeText(this, "Alarm sound सेव्ह झाला. पुढील reminder ला लागू होईल.", Toast.LENGTH_LONG).show()
        if (targetButton == null) render()
    }

    private fun currentAlarmSoundUri(): Uri =
        prefs.getString("alarm_sound_uri", "")?.takeIf { it.isNotBlank() }?.let { Uri.parse(it) }
            ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
            ?: android.provider.Settings.System.DEFAULT_ALARM_ALERT_URI

    private fun alarmSoundName(uri: Uri): String = try {
        RingtoneManager.getRingtone(this, uri)?.getTitle(this) ?: "फोनचा default alarm"
    } catch (_: Exception) { "फोनचा default alarm" }

    private fun openRingtonePicker(targetButton: Button? = null) {
        val soundUri = currentAlarmSoundUri()
        val picker = Intent(RingtoneManager.ACTION_RINGTONE_PICKER).apply {
            putExtra(RingtoneManager.EXTRA_RINGTONE_TYPE, RingtoneManager.TYPE_ALARM)
            putExtra(RingtoneManager.EXTRA_RINGTONE_TITLE, "KAIZEN PRO alarm sound")
            putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_DEFAULT, true)
            putExtra(RingtoneManager.EXTRA_RINGTONE_DEFAULT_URI, RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
                ?: android.provider.Settings.System.DEFAULT_ALARM_ALERT_URI)
            putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_SILENT, false)
            putExtra(RingtoneManager.EXTRA_RINGTONE_EXISTING_URI, soundUri)
        }
        ringtoneButtonToUpdate = targetButton
        try {
            startActivityForResult(picker, 502)
        } catch (_: ActivityNotFoundException) {
            ringtoneButtonToUpdate = null
            Toast.makeText(this, "या फोनमध्ये ringtone निवडण्याची system सुविधा उपलब्ध नाही.", Toast.LENGTH_LONG).show()
        }
    }

    private fun exportBackup(uri: Uri) {
        try {
            val backup = JSONObject()
                .put("app", "KAIZEN PRO")
                .put("version", 1)
                .put("preferences", JSONObject(prefs.all))
            contentResolver.openOutputStream(uri)?.use { output ->
                output.write(backup.toString(2).toByteArray(Charsets.UTF_8))
            } ?: throw IllegalStateException("Backup file उघडता आली नाही")
            Toast.makeText(this, "Backup फाइल सेव्ह झाली.", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Backup सेव्ह करता आली नाही: ${e.localizedMessage ?: "त्रुटी"}", Toast.LENGTH_LONG).show()
        }
    }

    private fun confirmBackupRestore(uri: Uri) {
        AlertDialog.Builder(this)
            .setTitle("Backup restore करायचा?")
            .setMessage("सध्याचा app data निवडलेल्या backup मधील data ने बदलला जाईल.")
            .setNegativeButton("रद्द", null)
            .setPositiveButton("Restore") { _, _ -> restoreBackup(uri) }
            .show()
    }

    private fun restoreBackup(uri: Uri) {
        try {
            val raw = contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }
                ?: throw IllegalStateException("Backup फाइल वाचता आली नाही")
            val backup = JSONObject(raw)
            require(backup.optString("app") == "KAIZEN PRO") { "ही KAIZEN PRO ची backup फाइल नाही." }
            val saved = backup.getJSONObject("preferences")
            val editor = prefs.edit().clear()
            val keys = saved.keys()
            while (keys.hasNext()) {
                val key = keys.next()
                when (val value = saved.get(key)) {
                    is String -> editor.putString(key, value)
                    is Boolean -> editor.putBoolean(key, value)
                    is Number -> {
                        val longValue = value.toLong()
                        if (longValue in Int.MIN_VALUE..Int.MAX_VALUE && value.toDouble() == longValue.toDouble()) editor.putInt(key, longValue.toInt())
                        else editor.putLong(key, longValue)
                    }
                    JSONObject.NULL -> editor.remove(key)
                    else -> throw IllegalArgumentException("Backup मधील data format समर्थित नाही.")
                }
            }
            editor.apply()
            tasks.clear()
            loadTasks()
            scheduleAllReminders()
            render()
            Toast.makeText(this, "Backup restore झाला.", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Backup restore झाला नाही: ${e.localizedMessage ?: "फाइल तपासा"}", Toast.LENGTH_LONG).show()
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 501) {
            val granted = grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED
            Toast.makeText(this, if (granted) "सूचना परवानगी सुरू झाली" else "सूचना बंद आहेत. Settings मधून परवानगी सुरू करा.", Toast.LENGTH_LONG).show()
            if (page == "Settings / Backup") render()
        }
    }

    private fun loadTasks() {
        val count = prefs.getInt("count", -1)
        if (count < 0) {
            tasks.add(Task("उठल्यावर पाणी पिणे", "P2", false))
            tasks.add(Task("आजची 3 महत्त्वाची कामे ठरवणे", "P1", false))
            tasks.add(Task("15 मिनिटे चालणे / व्यायाम", "P2", false))
            tasks.add(Task("व्यवसायाची विक्री नोंदवणे", "P1", false))
            saveTasks()
        } else {
            for (i in 0 until count) {
                val title = prefs.getString("title_$i", "") ?: ""
                if (title.isBlank()) continue
                val type = prefs.getString("type_$i", "Daily") ?: "Daily"
                val savedDone = prefs.getBoolean("done_$i", false)
                val doneDate = prefs.getString("done_date_$i", "") ?: ""
                tasks.add(Task(title,
                    prefs.getString("priority_$i", "P3") ?: "P3",
                    savedDone && type != "Recurring" && (type != "Daily" || doneDate == todayKey()),
                    type,
                    prefs.getInt("interval_$i", 0),
                    prefs.getLong("due_$i", 0L),
                    prefs.getString("time_$i", "20:00") ?: "20:00",
                    prefs.getBoolean("reminder_enabled_$i", true),
                    prefs.getString("slot_$i", "") ?: "",
                    prefs.getInt("duration_$i", 60),
                    doneDate))
            }
        }
    }

    private fun saveTasks() {
        val previousCount = prefs.getInt("count", 0)
        ReminderScheduler.cancelAll(this, maxOf(previousCount, tasks.size))
        prefs.edit().apply {
            putInt("count", tasks.size)
            tasks.forEachIndexed { i, t ->
                putString("title_$i", t.title); putString("priority_$i", t.priority)
                putBoolean("done_$i", t.done); putString("type_$i", t.type)
                putInt("interval_$i", t.intervalDays); putLong("due_$i", t.dueAt)
                putString("time_$i", t.reminderTime)
                putBoolean("reminder_enabled_$i", t.reminderEnabled)
                putString("slot_$i", t.slotTime)
                putInt("duration_$i", t.durationMinutes)
                putString("done_date_$i", if (t.done && t.type == "Daily") todayKey() else t.doneDate)
            }
            apply()
        }
        scheduleAllReminders()
    }

    private fun createNotificationChannel() {
        ReminderReceiver.ensureChannel(this)
    }

    private fun scheduleAllReminders() {
        ReminderScheduler.scheduleAll(this)
    }

    private fun render() {
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(bg); setPadding(dp(12), dp(12), dp(12), dp(14)) }
        val scroll = ScrollView(this).apply { isFillViewport = true }
        scroll.addView(root, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        setContentView(scroll)
        if (page == "Dashboard") {
            text(root, "KAIZEN PRO", 28f, red, true)
            text(root, "NO EXCUSES. JUST ACTION.", 12f, muted, true, 0, 12)
            val nav = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; minimumHeight = dp(6 * 72) }
            root.addView(nav, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
            val destinations = listOf(
                "Today Plan" to "🗓️", "Daily Tasks" to "✅", "Recurring Tasks" to "🔁", "Upcoming Tasks" to "📅",
                "Life Learnings" to "🌱", "Fitness" to "💪", "Brain Development" to "🧠", "Personality Development" to "✨",
                "Money Management" to "💰", "90 Days Challenge" to "🏆", "Progress Reports" to "📊", "Settings / Backup" to "⚙️"
            )
            destinations.chunked(2).forEach { pair ->
                val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; minimumHeight = dp(72) }
                pair.forEach { (label, symbol) ->
                    val tile = LinearLayout(this).apply {
                        orientation = LinearLayout.VERTICAL
                        gravity = Gravity.CENTER
                        setPadding(dp(4), dp(4), dp(4), dp(4))
                        setBackgroundColor(card)
                        isClickable = true
                        isFocusable = true
                        contentDescription = "$symbol $label उघडा"
                        setOnClickListener { page = label; render() }
                    }
                    tile.minimumHeight = dp(64)
                    val icon = TextView(this).apply { text = symbol; textSize = 28f; gravity = Gravity.CENTER }
                    val caption = TextView(this).apply { text = label; textSize = 12f; setTextColor(white); gravity = Gravity.CENTER; maxLines = 2 }
                    tile.addView(icon, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
                    tile.addView(caption, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
                    val lp = LinearLayout.LayoutParams(0, 0, 1f); lp.setMargins(dp(4), dp(4), dp(4), dp(4)); row.addView(tile, lp)
                }
                nav.addView(row, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
            }
            text(root, "तुझा वैयक्तिक प्रगती आढावा", 18f, white, true, 8, 4)
        } else {
            val topBar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            val back = Button(this).apply {
                text = "‹ मुख्य मेनू"; textSize = 13f; minHeight = dp(40)
                setTextColor(white); setBackgroundColor(card)
                setOnClickListener { page = "Dashboard"; render() }
            }
            topBar.addView(back, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(42)))
            val brand = TextView(this).apply { text = "KAIZEN PRO"; textSize = 16f; setTextColor(red); setTypeface(typeface, Typeface.BOLD); gravity = Gravity.CENTER_VERTICAL; setPadding(dp(10), 0, 0, 0) }
            topBar.addView(brand)
            root.addView(topBar, matchWrap())
            text(root, when(page) {
                "Daily Tasks" -> "आजची कामं"
                "Recurring Tasks" -> "🔁 पुन्हा पुन्हा करायची कामं"
                "Upcoming Tasks" -> "📅 पुढील ७ दिवस"
                "Today Plan" -> "🗓️ आजचं वेळापत्रक"
                "Life Learnings" -> "🌱 Life Learnings"
                else -> page
            }, 21f, white, true, 8, 8)
        }
        content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(content, matchWrap())
        when(page) {
            "Dashboard" -> showDashboard()
            "Today Plan" -> showTodayPlan()
            "Daily Tasks" -> showTasks("Daily")
            "Recurring Tasks" -> showTasks("Recurring")
            "Upcoming Tasks" -> showUpcoming()
            "Life Learnings" -> showLifeLearnings()
            "Fitness" -> showCategory("Fitness", listOf("15 मिनिटे चालणे / व्यायाम", "पाणी पिण्याची नोंद", "झोपेची वेळ नोंदवणे"))
            "Brain Development" -> showCategory("Brain", listOf("10 मिनिटे वाचन", "आज शिकलेली एक गोष्ट लिहा", "स्मरणशक्तीचा सराव"))
            "Personality Development" -> showCategory("Personality", listOf("10 मिनिटे बोलण्याचा सराव", "आजची एक सुधारणा लिहा", "नवीन कौशल्याचा सराव"))
            "Money Management" -> showMoney()
            "90 Days Challenge" -> showChallenge()
            "Progress Reports" -> showReports()
            "Settings / Backup" -> showSettings()
            else -> showDashboard()
        }
        text(root, "कामे Offline सेव्ह होतात. Recurring Reminder साठी सूचना परवानगी आवश्यक आहे.", 12f, muted, false, 12, 0)
    }

    override fun onBackPressed() {
        if (page != "Dashboard") {
            page = "Dashboard"
            render()
        } else super.onBackPressed()
    }

    private fun showDashboard() {
        val daily = tasks.filter { it.type == "Daily" }
        val done = daily.count { it.done }; val pct = if (daily.isEmpty()) 0 else done * 100 / daily.size
        panel("TODAY'S MISSION", "$pct% • $done / ${daily.size} कामं पूर्ण")
        val recurring = tasks.count { it.type == "Recurring" }
        panel("RECURRING TASKS", "$recurring कामे नियोजित")
        panel("UPCOMING", "पुढील ७ दिवसांतील ${tasks.count { it.dueAt > 0L }} नियोजित कामे")
        button(content, "+ रोजचे काम जोडा", red) { addTaskDialog("Daily") }
        button(content, "+ Recurring काम जोडा", red) { addTaskDialog("Recurring") }
        button(content, "आजची कामं Reset करा", card) {
            AlertDialog.Builder(this).setTitle("Reset करायचं?").setMessage("फक्त रोजच्या कामांच्या पूर्ण खूणा काढल्या जातील.")
                .setNegativeButton("रद्द", null).setPositiveButton("Reset") { _, _ -> daily.forEach { it.done = false; it.doneDate = "" }; saveTasks(); render() }.show()
        }
    }

    private fun showTodayPlan() {
        val today = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        }
        val tomorrow = (today.clone() as Calendar).apply { add(Calendar.DAY_OF_YEAR, 1) }.timeInMillis
        val items = tasks.withIndex().filter { indexed ->
            val task = indexed.value
            task.type == "Daily" || (task.type == "Recurring" && task.dueAt > 0L && task.dueAt < tomorrow)
        }.map { it.index to it.value }
        val complete = items.count { it.second.done }
        panel("आजची कामं", "$complete / ${items.size} पूर्ण • रोजची आणि आज देय recurring कामं")
        val startKey = "plan_start_minute"
        val endKey = "plan_end_minute"
        var dayStart = prefs.getInt(startKey, 8 * 60)
        var dayEnd = prefs.getInt(endKey, 22 * 60)
        val window = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val startButton = Button(this).apply { text = "दिवस सुरू: ${formatMinutes(dayStart)}" }
        val endButton = Button(this).apply { text = "दिवस संपतो: ${formatMinutes(dayEnd)}" }
        startButton.setOnClickListener {
            TimePickerDialog(this, { _, h, m ->
                val proposed = h * 60 + m
                if (proposed >= dayEnd) Toast.makeText(this, "सुरुवातीची वेळ शेवटच्या वेळेपेक्षा आधी असावी.", Toast.LENGTH_SHORT).show()
                else { dayStart = proposed; prefs.edit().putInt(startKey, dayStart).apply(); render() }
            }, dayStart / 60, dayStart % 60, true).show()
        }
        endButton.setOnClickListener {
            TimePickerDialog(this, { _, h, m ->
                val proposed = h * 60 + m
                if (proposed <= dayStart) Toast.makeText(this, "शेवटची वेळ सुरुवातीच्या वेळेपेक्षा नंतर असावी.", Toast.LENGTH_SHORT).show()
                else { dayEnd = proposed; prefs.edit().putInt(endKey, dayEnd).apply(); render() }
            }, dayEnd / 60, dayEnd % 60, true).show()
        }
        window.addView(startButton, LinearLayout.LayoutParams(0, dp(48), 1f))
        window.addView(endButton, LinearLayout.LayoutParams(0, dp(48), 1f))
        content.addView(window, matchWrap())
        text(content, "Slot म्हणजे कामासाठी राखलेला वेळ; Alarm वेळ स्वतंत्र आहे. कामं आपोआप पुढे सरकवली जात नाहीत.", 12f, muted, false, 2, 8)

        val scheduled = items.filter { it.second.slotTime.isNotBlank() }
            .sortedBy { parseMinutes(it.second.slotTime) }
        val unscheduled = items.filter { it.second.slotTime.isBlank() }
        var cursor = dayStart
        var overlap = false
        scheduled.forEach { (index, task) ->
            val start = parseMinutes(task.slotTime)
            val end = start + task.durationMinutes.coerceAtLeast(5)
            if (start >= dayStart && start < dayEnd) {
                if (start < cursor) {
                    overlap = true
                    panel("वेळा एकमेकांवर आल्या", "${task.title} • ${formatMinutes(start)} पासून")
                } else if (start > cursor) {
                    val freeStart = cursor
                    val freeEnd = start
                    panel("मोकळा slot  •  काम जोडण्यासाठी टॅप करा", freeSlotDetail(freeStart, freeEnd), freeSlotCard, freeSlotAccent) {
                        addTaskInFreeSlot(freeStart, freeEnd)
                    }
                }
                val warning = if (end > dayEnd) " • उपलब्ध वेळेबाहेर" else ""
                if (warning.isNotBlank()) panel("वेळ तपासा", "${task.title}$warning")
                addTodayPlanTask(index, task, "${formatMinutes(start)} • ${task.durationMinutes} मिनिटे")
                if (end > cursor) cursor = end
            } else {
                panel("दिवसाच्या वेळेबाहेर", "${task.title} • ${task.slotTime}")
                addTodayPlanTask(index, task, "${task.slotTime} • ${task.durationMinutes} मिनिटे")
            }
        }
        if (cursor < dayEnd) {
            val freeStart = cursor
            val freeEnd = dayEnd
            panel("मोकळा slot  •  काम जोडण्यासाठी टॅप करा", freeSlotDetail(freeStart, freeEnd), freeSlotCard, freeSlotAccent) {
                addTaskInFreeSlot(freeStart, freeEnd)
            }
        }
        if (overlap) text(content, "जुळणारे slots स्वतः तपासा; app ने कोणतीही वेळ आपोआप बदललेली नाही.", 12f, red, true, 2, 6)
        if (unscheduled.isNotEmpty()) {
            text(content, "वेळ ठरवायची कामं", 16f, white, true, 8, 3)
            unscheduled.forEach { (index, task) ->
                addTodayPlanTask(index, task, "वेळ ठरवायची")
            }
        }
        if (items.isEmpty()) text(content, "आजसाठी कामं नाहीत. रोजचं किंवा recurring काम जोडा.", 14f, muted, false, 4, 8)
    }

    private fun addTodayPlanTask(index: Int, task: Task, detail: String) {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), dp(3), dp(8), dp(3))
            setBackgroundColor(card)
        }
        val check = CheckBox(this).apply {
            isChecked = task.done
            buttonTintList = android.content.res.ColorStateList.valueOf(if (task.done) Color.GREEN else red)
        }
        check.setOnCheckedChangeListener { _, checked ->
            if (task.type == "Recurring" && checked) {
                task.done = false
                task.dueAt = ReminderScheduler.nextDueDate(task.dueAt, task.intervalDays)
                Toast.makeText(this, "पूर्ण! पुढील तारीख ${formatDate(task.dueAt)}", Toast.LENGTH_LONG).show()
            } else task.done = checked
            if (task.type == "Daily") task.doneDate = if (checked) todayKey() else ""
            saveTasks(); render()
        }
        row.addView(check)
        val label = TextView(this).apply {
            text = "${task.title}\n$detail${if (task.type == "Recurring") " • पुढची तारीख: ${formatDate(task.dueAt)}" else ""}"
            textSize = 14f
            setTextColor(if (task.done) muted else white)
            setPadding(dp(4), dp(5), dp(4), dp(5))
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        row.addView(label)
        val edit = TextView(this).apply {
            text = "✎"; textSize = 22f; gravity = Gravity.CENTER
            setTextColor(freeSlotAccent); contentDescription = "वेळ आणि कालावधी बदला"
            setOnClickListener { scheduleTaskDialog(index) }
        }
        row.addView(edit, LinearLayout.LayoutParams(dp(42), dp(44)))
        val lp = matchWrap(); lp.bottomMargin = dp(5)
        content.addView(row, lp)
    }

    private fun addTaskInFreeSlot(startMinute: Int, endMinute: Int) {
        val available = endMinute - startMinute
        if (available < 5) {
            Toast.makeText(this, "या मोकळ्या slot मध्ये काम जोडण्यासाठी पुरेसा वेळ नाही.", Toast.LENGTH_SHORT).show()
            return
        }
        val form = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(8), dp(20), 0) }
        val title = EditText(this).apply { hint = "कामाचं नाव"; setTextColor(white); setHintTextColor(muted) }
        form.addView(title, matchWrap())
        val duration = EditText(this).apply {
            hint = "कालावधी मिनिटांत (कमाल $available)"
            inputType = 2
            setTextColor(white); setHintTextColor(muted)
            setText(minOf(60, available).toString())
        }
        form.addView(duration, matchWrap())
        AlertDialog.Builder(this).setTitle("मोकळ्या वेळेत काम जोडा")
            .setMessage("${formatMinutes(startMinute)} पासून ${formatMinutes(endMinute)} पर्यंत • हे काम Daily Tasks मध्येही दिसेल")
            .setView(form).setNegativeButton("रद्द", null)
            .setPositiveButton("जोडा") { _, _ ->
                val name = title.text.toString().trim()
                val minutes = duration.text.toString().toIntOrNull()
                if (name.isBlank()) {
                    Toast.makeText(this, "कामाचं नाव लिहा.", Toast.LENGTH_SHORT).show()
                } else if (minutes == null || minutes !in 5..available) {
                    Toast.makeText(this, "कालावधी 5 ते $available मिनिटांदरम्यान द्या.", Toast.LENGTH_LONG).show()
                } else {
                    tasks.add(Task(name, "P2", false, "Daily", slotTime = formatMinutes(startMinute), durationMinutes = minutes))
                    saveTasks()
                    Toast.makeText(this, "काम मोकळ्या slot मध्ये जोडले.", Toast.LENGTH_SHORT).show()
                    render()
                }
            }.show()
    }

    private fun scheduleTaskDialog(index: Int) {
        if (index !in tasks.indices) return
        val task = tasks[index]
        val form = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(8), dp(20), 0) }
        var time = task.slotTime.ifBlank { formatMinutes(prefs.getInt("plan_start_minute", 8 * 60)) }
        val timeButton = Button(this).apply { text = "काम सुरू: $time" }
        timeButton.setOnClickListener {
            val parts = time.split(":")
            TimePickerDialog(this, { _, h, m ->
                time = String.format(Locale.US, "%02d:%02d", h, m)
                timeButton.text = "काम सुरू: $time"
            }, parts.getOrNull(0)?.toIntOrNull() ?: 8, parts.getOrNull(1)?.toIntOrNull() ?: 0, true).show()
        }
        form.addView(timeButton)
        val duration = EditText(this).apply {
            hint = "कालावधी मिनिटांत (उदा. 60)"
            inputType = 2
            setTextColor(white); setHintTextColor(muted)
            setText(task.durationMinutes.toString())
        }
        form.addView(duration, matchWrap())
        AlertDialog.Builder(this).setTitle("आजच्या कामाचा slot").setMessage(task.title).setView(form)
            .setNegativeButton("रद्द", null)
            .setNeutralButton("Slot काढा") { _, _ -> task.slotTime = ""; saveTasks(); render() }
            .setPositiveButton("सेव्ह") { _, _ ->
                val minutes = duration.text.toString().toIntOrNull()
                if (minutes == null || minutes !in 5..1440) {
                    Toast.makeText(this, "कालावधी 5 ते 1440 मिनिटांदरम्यान द्या.", Toast.LENGTH_LONG).show()
                } else {
                    task.slotTime = time
                    task.durationMinutes = minutes
                    saveTasks(); render()
                }
            }.show()
    }

    private fun showLifeLearnings() {
        text(content, "अनुभवातून शिकलेली गोष्ट, पुढच्या वेळी काय कराल किंवा स्वतःमध्ये केलेली सुधारणा लिहा. हा वैयक्तिक आणि ऐच्छिक नोंदवहीचा भाग आहे.", 14f, muted, false, 0, 8)
        button(content, "+ Life Learning लिहा", red) { learningDialog(null, null) }
        val entries = loadLearnings()
        if (entries.isEmpty()) {
            text(content, "अजून नोंद नाही. शिकलेली एखादी गोष्ट कधीही लिहू शकता.", 14f, muted, false, 4, 8)
            return
        }
        var lastDate = ""
        entries.forEachIndexed { index, entry ->
            if (entry.date != lastDate) {
                lastDate = entry.date
                text(content, learningDateLabel(entry.date), 15f, red, true, 10, 4)
            }
            panel("Life Learning", entry.note)
            val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            val edit = Button(this).apply { text = "Edit"; setOnClickListener { learningDialog(index, entry) } }
            val delete = Button(this).apply { text = "Delete"; setOnClickListener {
                AlertDialog.Builder(this@MainActivity).setTitle("नोंद delete करायची?")
                    .setMessage(entry.note).setNegativeButton("रद्द", null)
                    .setPositiveButton("Delete") { _, _ ->
                        val updated = loadLearnings().toMutableList()
                        if (index in updated.indices) updated.removeAt(index)
                        saveLearnings(updated); render()
                    }.show()
            } }
            actions.addView(edit, LinearLayout.LayoutParams(0, dp(48), 1f))
            actions.addView(delete, LinearLayout.LayoutParams(0, dp(48), 1f))
            content.addView(actions, matchWrap())
        }
    }

    private fun loadLearnings(): List<Learning> {
        val count = prefs.getInt("learning_count", 0)
        return (0 until count).mapNotNull { i ->
            val note = prefs.getString("learning_note_$i", null) ?: return@mapNotNull null
            Learning(prefs.getString("learning_date_$i", todayKey()) ?: todayKey(), note)
        }.sortedByDescending { it.date }
    }

    private fun saveLearnings(entries: List<Learning>) {
        prefs.edit().apply {
            putInt("learning_count", entries.size)
            entries.forEachIndexed { i, entry ->
                putString("learning_date_$i", entry.date)
                putString("learning_note_$i", entry.note)
            }
            apply()
        }
    }

    private fun learningDialog(index: Int?, existing: Learning?) {
        val input = EditText(this).apply {
            hint = "आज काय शिकलात? पुढच्या वेळी काय वेगळं कराल?"
            setTextColor(white); setHintTextColor(muted)
            minLines = 3; gravity = Gravity.TOP
            setPadding(dp(16), dp(10), dp(16), dp(10))
            setText(existing?.note ?: "")
        }
        AlertDialog.Builder(this).setTitle(if (existing == null) "Life Learning" else "Life Learning edit करा")
            .setView(input).setNegativeButton("रद्द", null)
            .setPositiveButton(if (existing == null) "जतन करा" else "बदल जतन करा") { _, _ ->
                val note = input.text.toString().trim()
                if (note.isBlank()) {
                    Toast.makeText(this, "नोंद रिकामी ठेवू नका.", Toast.LENGTH_SHORT).show()
                } else {
                    val entries = loadLearnings().toMutableList()
                    if (index == null) entries.add(0, Learning(todayKey(), note))
                    else if (index in entries.indices) entries[index] = Learning(existing?.date ?: todayKey(), note)
                    saveLearnings(entries); render()
                }
            }.show()
    }

    private fun todayKey(): String = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
    private fun learningDateLabel(key: String): String = try {
        SimpleDateFormat("dd MMM yyyy", Locale("mr", "IN")).format(SimpleDateFormat("yyyy-MM-dd", Locale.US).parse(key)!!)
    } catch (_: Exception) { key }
    private fun parseMinutes(value: String): Int {
        val parts = value.split(":")
        val hour = parts.getOrNull(0)?.toIntOrNull()?.coerceIn(0, 23) ?: 8
        val minute = parts.getOrNull(1)?.toIntOrNull()?.coerceIn(0, 59) ?: 0
        return hour * 60 + minute
    }
    private fun formatMinutes(value: Int): String = String.format(Locale.US, "%02d:%02d", (value / 60).coerceIn(0, 23), value % 60)
    private fun freeSlotDetail(startMinute: Int, endMinute: Int): String =
        "${formatMinutes(startMinute)} – ${formatMinutes(endMinute)} • ${formatDuration(endMinute - startMinute)}"
    private fun formatDuration(durationMinutes: Int): String {
        val total = durationMinutes.coerceAtLeast(0)
        val hours = total / 60
        val minutes = total % 60
        return when {
            hours > 0 && minutes > 0 -> "$hours तास $minutes मिनिटे"
            hours > 0 -> "$hours तास"
            else -> "$minutes मिनिटे"
        }
    }

    private fun showTasks(type: String) {
        val filtered = tasks.withIndex().filter { it.value.type == type }
        if (filtered.isEmpty()) text(content, "या विभागात अजून कामे नाहीत.", 15f, muted, false, 0, 8)
        val ordered = filtered.sortedWith(compareBy<IndexedValue<Task>> { it.value.done }.thenBy { it.index })
        val incompleteCount = ordered.count { !it.value.done }
        if (incompleteCount > 0 && ordered.any { it.value.done }) {
            text(content, "बाकी कामं", 13f, red, true, 2, 4)
        }
        ordered.forEachIndexed { displayIndex, indexed ->
            if (displayIndex == incompleteCount && incompleteCount > 0 && ordered.any { it.value.done }) {
                text(content, "पूर्ण झालेली कामं", 13f, muted, true, 8, 4)
            }
            val i = indexed.index; val t = indexed.value
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(6), dp(4), dp(3), dp(4)); setBackgroundColor(card) }
            val cb = CheckBox(this).apply { isChecked = t.done; buttonTintList = android.content.res.ColorStateList.valueOf(if (t.done) Color.GREEN else red) }
            cb.setOnCheckedChangeListener { _, checked ->
                if (t.type == "Recurring" && checked) {
                    t.done = false
                    t.dueAt = ReminderScheduler.nextDueDate(t.dueAt, t.intervalDays)
                    Toast.makeText(this, "पूर्ण! पुढील तारीख ${formatDate(t.dueAt)}", Toast.LENGTH_LONG).show()
                } else t.done = checked
                if (t.type == "Daily") t.doneDate = if (checked) todayKey() else ""
                saveTasks(); render()
            }
            row.addView(cb)
            val detail = if (t.type == "Recurring") "\n${t.intervalDays} दिवसांनी • पुढील तारीख: ${if (t.dueAt > 0L) formatDate(t.dueAt) else "अजून ठरलेली नाही"} • ${t.reminderTime} • ${if (t.reminderEnabled) "⏰ Alarm चालू" else "Alarm बंद"}" else "\n${t.priority}"
            val label = TextView(this).apply { text = t.title + detail; textSize = 14f; setTextColor(if (t.done) muted else white); setPadding(dp(4), 0, dp(4), 0); layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f) }
            row.addView(label)
            if (t.type == "Recurring") {
                val reminderSwitch = Switch(this).apply {
                    text = "Alarm"
                    isChecked = t.reminderEnabled
                    setTextColor(white)
                    setOnCheckedChangeListener { _, enabled ->
                        t.reminderEnabled = enabled
                        saveTasks()
                        render()
                    }
                }
                row.addView(reminderSwitch)
            }
            val del = Button(this).apply { text = "×"; setTextColor(red); setBackgroundColor(card); setOnClickListener { AlertDialog.Builder(this@MainActivity).setTitle("काम डिलीट करायचं?").setMessage(t.title).setNegativeButton("रद्द", null).setPositiveButton("डिलीट") { _, _ -> tasks.removeAt(i); saveTasks(); render() }.show() } }
            row.addView(del)
            val lp = matchWrap(); lp.bottomMargin = dp(4); content.addView(row, lp)
        }
        button(content, if (type == "Recurring") "+ नवीन Recurring काम" else "+ नवीन काम जोडा", red) { addTaskDialog(type) }
    }

    private fun showUpcoming() {
        val now = System.currentTimeMillis(); val end = now + 7L * 86400000L
        val upcoming = tasks.filter { it.dueAt in now..end }
        if (upcoming.isEmpty()) text(content, "पुढील ७ दिवसांसाठी नियोजित कामे नाहीत.", 15f, muted, false)
        upcoming.sortedBy { it.dueAt }.forEach { panel(it.title, "${formatDate(it.dueAt)} • ${it.type}") }
    }

    private fun showCategory(type: String, examples: List<String>) {
        text(content, "ही सुरुवातीची नमुना कामे आहेत. + बटणाने तुमची कामे जोडा.", 13f, muted, false, 0, 8)
        examples.forEach { name -> button(content, "+ $name", card) { tasks.add(Task(name, "P2", false, "Daily")); saveTasks(); Toast.makeText(this, "काम Daily Tasks मध्ये जोडले", Toast.LENGTH_SHORT).show(); page = "Daily Tasks"; render() } }
        button(content, "या विभागासाठी काम जोडा", red) { addTaskDialog("Daily") }
    }

    private fun showMoney() {
        text(content, "साधा उत्पन्न/खर्च हिशेब", 15f, muted, false, 0, 8)
        val income = EditText(this).apply { hint = "उत्पन्न (₹)"; inputType = 2; setTextColor(white); setHintTextColor(muted) }
        val expense = EditText(this).apply { hint = "खर्च (₹)"; inputType = 2; setTextColor(white); setHintTextColor(muted) }
        content.addView(income, matchWrap()); content.addView(expense, matchWrap())
        val result = text(content, "निव्वळ: ₹0", 20f, white, true, 8, 8)
        button(content, "हिशेब काढा", red) { val a = income.text.toString().toDoubleOrNull() ?: 0.0; val b = expense.text.toString().toDoubleOrNull() ?: 0.0; result.text = "निव्वळ: ₹${a-b}" }
        text(content, "टीप: हा हिशेब सध्या स्क्रीनवरच आहे; कायमस्वरूपी नोंद/रिपोर्ट पुढील टप्प्यात जोडायचा आहे.", 12f, muted, false, 8, 0)
    }

    private fun showChallenge() {
        val start = prefs.getLong("challenge_start", 0L)
        if (start == 0L) {
            text(content, "९० दिवसांचा वैयक्तिक सुधारणा प्रवास सुरू करा.", 15f, muted, false, 0, 8)
            button(content, "90 Days Challenge सुरू करा", red) { prefs.edit().putLong("challenge_start", System.currentTimeMillis()).apply(); render() }
        } else {
            val day = ((System.currentTimeMillis() - start) / 86400000L + 1).toInt().coerceIn(1, 90)
            panel("90 DAYS CHALLENGE", "दिवस $day / 90")
            val bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 90; progress = day; progressTintList = android.content.res.ColorStateList.valueOf(red) }
            content.addView(bar, matchWrap())
            button(content, "Challenge पुन्हा सुरू करा", card) { AlertDialog.Builder(this).setMessage("नवीन ९० दिवसांचा प्रवास सुरू करायचा?").setNegativeButton("रद्द", null).setPositiveButton("हो") { _, _ -> prefs.edit().putLong("challenge_start", System.currentTimeMillis()).apply(); render() }.show() }
        }
    }

    private fun showReports() {
        val daily = tasks.filter { it.type == "Daily" }; val recurring = tasks.filter { it.type == "Recurring" }
        panel("सर्व कामे", "${tasks.size}")
        panel("रोजची कामे पूर्ण", "${daily.count { it.done }} / ${daily.size}")
        panel("Recurring कामे", "${recurring.size} • पूर्ण केलेली ${recurring.count { it.done }}")
        text(content, "हा प्राथमिक आढावा आहे. साप्ताहिक/मासिक इतिहास पुढील टप्प्यात जोडायचा आहे.", 12f, muted, false, 8, 0)
    }

    private fun showSettings() {
        val notificationAllowed = Build.VERSION.SDK_INT < 33 ||
            checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
        panel("सूचना", if (notificationAllowed) "सूचना परवानगी सुरू आहे" else "सूचना परवानगी बंद आहे — alarm दिसणार/ऐकू येणार नाही")
        if (!notificationAllowed) {
            button(content, "सूचना परवानगी सुरू करा", red) {
                requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 501)
            }
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            button(content, "KAIZEN PRO alarm सूचना सेटिंग", card) {
                val settingsIntent = Intent(android.provider.Settings.ACTION_CHANNEL_NOTIFICATION_SETTINGS).apply {
                    putExtra(android.provider.Settings.EXTRA_APP_PACKAGE, packageName)
                    putExtra(android.provider.Settings.EXTRA_CHANNEL_ID, ReminderReceiver.channelId(this@MainActivity))
                }
                try { startActivity(settingsIntent) }
                catch (_: Exception) {
                    try {
                        startActivity(Intent(android.provider.Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                            .putExtra(android.provider.Settings.EXTRA_APP_PACKAGE, packageName))
                    } catch (_: Exception) {
                        Toast.makeText(this, "फोनच्या Settings → Apps → KAIZEN PRO → Notifications येथे जा.", Toast.LENGTH_LONG).show()
                    }
                }
            }
        }
        val soundUri = currentAlarmSoundUri()
        panel("Alarm sound", alarmSoundName(soundUri))
        button(content, "Alarm ringtone / आवाज निवडा", red) {
            openRingtonePicker()
        }
        text(content, "प्रेरणादायी voice clip वापरायचा असल्यास आधी तो फोनच्या Alarm ringtone मध्ये जोडा, मग इथे निवडा. Channel मधील sound Android Settings मधूनही बदलता येतो.", 12f, muted, false, 0, 6)
        val exactAllowed = Build.VERSION.SDK_INT < Build.VERSION_CODES.S ||
            (getSystemService(ALARM_SERVICE) as AlarmManager).canScheduleExactAlarms()
        panel("Alarm वेळेवर वाजण्यासाठी", if (exactAllowed) "Exact alarm परवानगी सुरू आहे" else "Exact alarm परवानगी बंद आहे; Android सूचना उशिरा देऊ शकतो")
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !exactAllowed) {
            button(content, "वेळेवर Alarm साठी परवानगी द्या", red) {
                try {
                    startActivity(Intent(android.provider.Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,
                        android.net.Uri.parse("package:$packageName")))
                } catch (_: Exception) {
                    Toast.makeText(this, "Settings → Apps → KAIZEN PRO → Alarms & reminders सुरू करा", Toast.LENGTH_LONG).show()
                }
            }
        }
        panel("डेटा", "कामे आणि app मधील सेटिंग्स या फोनमध्ये सेव्ह होतात. सुरक्षित copy ठेवण्यासाठी Export करा.")
        button(content, "⬆️ Backup Export करा", red) {
            val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = "application/json"
                putExtra(Intent.EXTRA_TITLE, "kaizen-pro-backup.json")
            }
            try { startActivityForResult(intent, 503) }
            catch (_: ActivityNotFoundException) { Toast.makeText(this, "फाइल सेव्ह करण्याची system सुविधा उपलब्ध नाही.", Toast.LENGTH_LONG).show() }
        }
        button(content, "⬇️ Backup Restore करा", card) {
            val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = "application/json"
            }
            try { startActivityForResult(intent, 504) }
            catch (_: ActivityNotFoundException) { Toast.makeText(this, "फाइल निवडण्याची system सुविधा उपलब्ध नाही.", Toast.LENGTH_LONG).show() }
        }
        text(content, "Restore केल्यावर सध्याचा app data निवडलेल्या backup ने बदलला जाईल.", 13f, muted, false, 8, 0)
    }

    private fun addTaskDialog(type: String) {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(8), dp(20), 0) }
        val input = EditText(this).apply { hint = "कामाचं नाव"; setTextColor(white); setHintTextColor(muted) }; box.addView(input)
        val priority = Spinner(this).apply { adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, listOf("P1 - तातडीचे", "P2 - महत्त्वाचे", "P3 - सामान्य", "P4 - कमी")) }; box.addView(priority)
        var interval = 7
        var reminder = "20:00"
        var reminderEnabled = true
        if (type == "Recurring") {
            val startDate = Calendar.getInstance().apply {
                set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0)
                set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
            }
            val startDateButton = Button(this).apply {
                text = "सुरू तारीख (आज): ${formatDate(startDate.timeInMillis)}"
                setOnClickListener {
                    DatePickerDialog(this@MainActivity, { _, year, month, day ->
                        startDate.set(year, month, day, 0, 0, 0); startDate.set(Calendar.MILLISECOND, 0)
                        text = "सुरू तारीख: ${formatDate(startDate.timeInMillis)}"
                    }, startDate.get(Calendar.YEAR), startDate.get(Calendar.MONTH), startDate.get(Calendar.DAY_OF_MONTH)).apply {
                        datePicker.minDate = Calendar.getInstance().apply {
                            set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0)
                            set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
                        }.timeInMillis
                    }.show()
                }
            }
            box.addView(startDateButton)
            text(box, "आजची निवडलेली वेळ पुढे असेल तर पहिला alarm आज; वेळ निघून गेली असेल तर पुढच्या interval दिवशी.", 12f, muted, false, 2, 4)
            text(box, "पुनरावृत्ती किती दिवसांनी?", 14f, white, true, 8, 2)
            val choices = listOf("दर 2 दिवसांनी", "दर 3 दिवसांनी", "दर 4 दिवसांनी", "दर 7 दिवसांनी", "दर 15 दिवसांनी", "दर 30 दिवसांनी", "स्वतःचे दिवस")
            val intervals = listOf(2,3,4,7,15,30,0)
            val repeat = Spinner(this).apply { adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, choices) }; box.addView(repeat)
            val custom = EditText(this).apply { hint = "स्वतःचे दिवस (पर्यायी)"; inputType = 2; setTextColor(white); setHintTextColor(muted) }; box.addView(custom)
            val alarmSwitch = Switch(this).apply {
                text = "⏰ Alarm / सूचना सुरू करा"
                isChecked = true
                setTextColor(white)
                setPadding(0, dp(8), 0, dp(4))
                setOnCheckedChangeListener { _, checked -> reminderEnabled = checked }
            }
            box.addView(alarmSwitch)
            val timeButton = Button(this).apply { text = "Alarm वेळ निवडा: 20:00"; setOnClickListener { TimePickerDialog(this@MainActivity, { _, h, m -> reminder = String.format(Locale.US, "%02d:%02d", h, m); text = "Alarm वेळ निवडा: $reminder" }, 20, 0, true).show() } }; box.addView(timeButton)
            val ringtoneButton = Button(this).apply {
                text = "🔔 Alarm आवाज निवडा: ${alarmSoundName(currentAlarmSoundUri())}"
                textSize = 14f
                setTextColor(white)
                setBackgroundColor(card)
                setOnClickListener { openRingtonePicker(this) }
            }
            box.addView(ringtoneButton, matchWrap())
            text(box, "हा आवाज सर्व KAIZEN PRO reminders साठी वापरला जाईल.", 12f, muted, false, 1, 4)
            repeat.setOnItemSelectedListener(object : AdapterView.OnItemSelectedListener {
                override fun onNothingSelected(parent: AdapterView<*>?) {}
                override fun onItemSelected(parent: AdapterView<*>?, view: android.view.View?, position: Int, id: Long) { interval = intervals[position]; custom.isEnabled = interval == 0 }
            })
            AlertDialog.Builder(this).setTitle("नवीन Recurring काम").setView(box).setNegativeButton("रद्द", null).setPositiveButton("सेव्ह") { _, _ ->
                val name = input.text.toString().trim()
                val days = if (interval == 0) custom.text.toString().toIntOrNull() ?: 7 else interval
                if (name.isNotBlank()) {
                    val p = listOf("P1","P2","P3","P4")[priority.selectedItemPosition]
                    val next = ReminderScheduler.firstDueDate(startDate.timeInMillis, days.coerceAtLeast(1), reminder)
                    tasks.add(Task(name,p,false,"Recurring",days.coerceAtLeast(1),next,reminder,reminderEnabled))
                    saveTasks(); render()
                } else Toast.makeText(this, "कामाचं नाव लिहा", Toast.LENGTH_SHORT).show()
            }.show()
        } else {
            AlertDialog.Builder(this).setTitle("नवीन काम").setView(box).setNegativeButton("रद्द", null).setPositiveButton("जोडा") { _, _ ->
                val name = input.text.toString().trim(); if (name.isNotBlank()) { tasks.add(Task(name, listOf("P1","P2","P3","P4")[priority.selectedItemPosition], false, type)); saveTasks(); render() } else Toast.makeText(this,"कामाचं नाव लिहा",Toast.LENGTH_SHORT).show()
            }.show()
        }
    }

    private fun panel(title: String, detail: String, background: Int = card, titleColor: Int = red, onClick: (() -> Unit)? = null) {
        val p = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(9), dp(14), dp(9))
            setBackgroundColor(background)
            if (onClick != null) {
                isClickable = true
                isFocusable = true
                setOnClickListener { onClick() }
            }
        }
        text(p, title, 13f, titleColor, true); text(p, detail, 18f, white, true, 3, 0)
        val lp = matchWrap(); lp.bottomMargin = dp(5); content.addView(p, lp)
    }
    private fun formatDate(time: Long): String = SimpleDateFormat("dd MMM yyyy", Locale("mr", "IN")).format(Date(time))
    private fun text(parent: LinearLayout, value: String, size: Float, color: Int, bold: Boolean, top: Int = 0, bottom: Int = 0): TextView {
        val v = TextView(this).apply { text = value; textSize = size; setTextColor(color); if (bold) setTypeface(typeface, Typeface.BOLD); setPadding(0, dp(top), 0, dp(bottom)) }
        parent.addView(v, matchWrap()); return v
    }
    private fun button(parent: LinearLayout, label: String, color: Int, action: () -> Unit) {
        val b = Button(this).apply { text = label; textSize = 14f; minHeight = dp(44); setPadding(dp(8), dp(2), dp(8), dp(2)); setTextColor(white); setBackgroundColor(color); setOnClickListener { action() } }
        val lp = matchWrap(); lp.topMargin = dp(4); parent.addView(b, lp)
    }
    private fun matchWrap() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
}
