package com.kaizenpro.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class ReminderRescheduler : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        ReminderScheduler.scheduleAll(context)
    }
}
